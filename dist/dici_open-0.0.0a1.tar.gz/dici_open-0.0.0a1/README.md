# Dici

Dici is an alpha-stage command-line dictionary tool. It currently supports Jisho-based Japanese/English lookups from the terminal and provides a simple interactive menu for searching words.

## Features

- Interactive terminal UI with a menu-driven workflow
- Jisho API lookups for Japanese and English definitions
- Rich formatted output via `rich`

## Requirements

- Python 3.15 or later

## Install

From the project directory, install the package and its dependencies:

```bash
python -m pip install .
```

For local development, install in editable mode:

```bash
python -m pip install -e .
```

## Run

After installation, launch the CLI with either of these commands:

```bash
python -m dici
```

or:

```bash
dici
```

The app opens an interactive menu where you can choose dictionary sources and search for words.
